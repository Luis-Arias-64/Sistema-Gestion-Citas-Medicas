using SGCM.Domain.Entities;

namespace SGCM.Domain.Repository
{
    public interface IHospitalPersonalRepository : IBaseRepository<HospitalPersonal>
    {

    }
}