using SGCM.Domain.Entities;
using SGCM.Domain.Entities.Enum;

namespace SGCM.Domain.Repository
{
    public interface IApointmentRepository : IBaseRepository<Apointment>
    {
    }
}