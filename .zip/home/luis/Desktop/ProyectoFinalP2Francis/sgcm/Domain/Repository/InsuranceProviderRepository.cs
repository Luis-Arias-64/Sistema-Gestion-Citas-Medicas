using SGCM.Domain.Entities;

namespace SGCM.Domain.Repository
{
    public interface InsuranceProviderRepository : IBaseRepository<InsuranceProvider>
    {
    } 
}