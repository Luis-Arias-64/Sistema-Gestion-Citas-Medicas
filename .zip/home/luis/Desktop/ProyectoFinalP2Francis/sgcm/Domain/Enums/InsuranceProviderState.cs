namespace SGCM.Domain.Entities.Enum
{
    public enum InsuranceProviderState
    {
        Cancel, working, pending
    }
}