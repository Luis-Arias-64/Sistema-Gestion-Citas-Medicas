using SGCM.Domain.Repository;

namespace SGCM.Domain.Entities
{
    public sealed class HospitalPersonal : Person 
    {
    }    
}