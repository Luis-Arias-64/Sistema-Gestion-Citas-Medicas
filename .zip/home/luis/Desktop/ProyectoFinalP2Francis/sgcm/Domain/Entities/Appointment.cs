using SGCM.Domain.Repository;
using SGCM.Domain.Entities.Enum;

namespace SGCM.Domain.Entities
{
    public class Apointment 
    {
        private int id_Appointment {get;set;}
        private int Doctor_id {get;set;}
        private int Patient_id {get;set;}
        private string Description {get;set;}
        private DateTime ApointmentDate {get;set;}
        private EstateAppointment estateAppointment {get;set;}
        public Apointment(int id_Appointment,int doctor_id, int patient_id, DateTime ApointmentDate,string description)
        {
            this.id_Appointment = id_Appointment;
            this.Doctor_id = doctor_id;
            this.Patient_id = patient_id;
            this.ApointmentDate = ApointmentDate;
            this.Description = description;
            this.estateAppointment = EstateAppointment.Pendient;
        }
    }
}