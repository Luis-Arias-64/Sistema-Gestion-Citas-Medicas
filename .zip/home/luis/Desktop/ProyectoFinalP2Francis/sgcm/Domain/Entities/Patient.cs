namespace SGCM.Domain.Entities
{
    public sealed class Patient : Person
    {
    }   
}