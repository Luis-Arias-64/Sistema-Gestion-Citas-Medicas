﻿namespace IoC;

public class Class1
{

}
